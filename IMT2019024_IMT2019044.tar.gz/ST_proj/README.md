For our project we have used CFG analysis for our source code. The test-cases are in the TestCalc.java.
The testing tool used for this is jUnit. The screenshots are in the screenshots directory.
There 4 files in this zipped folder:-
src directory:
This has the Calculator source code in which the input has been integrated with the jUnit Testing Framework.
In order to see the output of the source code using the testing framework use the following 2 commands-

javac Calculator.java TestCalc.java TestRunner.java
java TestRunner

This will run the test-cases defined in Test-Calc.java file.
Now I will explain the input for the source code.

The first input decides which Calculator do we use, a Normal Calculator or a Scientific Calculator
1 - Normal Calculator
2 - Scientific Calculator

In normal calculator, we have 5 options
1 - Add
2 - Subtract
3 - Multiply
4 - Divide
5 - Modulo

Each of these operations act like an accumalator and only terminate once we send '=' as the input, that is, for example if we enter 1 1 10 15 20 = as input, it will return as the sum of 10, 15 and 20 as output.

In scientific Calculator we have:

1 TO FIND SQUARE ROOT

2 TO FIND RAISE TO POWER 'x'

3  TO FIND SQUARE

4  TO FIND CUBE

5  TO FIND TRIGNOMETRICAL VALUES

6  TO FIND ROOT TO X

7 ABSOLUTE VALUE

8 FIND ROUNDED OFF VALUE");

9 LOG

10 EXPONENTIAL VALUE

Additionally for trigonometry we have,
1 cosine
2 sine
3 tangent
4 cotangent
5 secant
6 cosecant
7 inverse-cosine
8 inverse-sine
9 inverse-tangent

Except for raise to power x and root to x, we just have a single input and rest have 2 inputs which is self explanatory.



code:
Additionally, we have provided the same source code with the main function and the input being taken from the console in the code folder.

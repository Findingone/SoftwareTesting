import java.util.*;
import java.io.*;
public class Calculator
{
    int choice,c1,c2;
    public static int calcInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        int res;
        while(true)
        {
            try
            {
                res=keyboard.nextInt();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static int normCalcInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        int res;
        while(true)
        {
            try
            {
                res=keyboard.nextInt();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static int scientCalcInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        int res;
        while(true)
        {
            try
            {
                res=keyboard.nextInt();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double addInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        int res;
        if(keyboard.hasNextInt())
        {
            while(true)
            {
                try
                {
                    res=keyboard.nextInt();
                }
                catch(NumberFormatException obj)
                {
                    System.out.println("Enter a valid number");
                    continue;
                }
                catch(Exception o)
                {
                    System.out.println("Error");
                    continue;
                }
                break;
            }
        }
        else 
        {
            while(true)
            {
                String x = keyboard.next();
                if(x.equals("="))
                {
                    return 0.1;
                }
            }
        }
        return res;
    }
    public static double subInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        int res;
        if(keyboard.hasNextInt())
        {
            while(true)
            {
                try
                {
                    res=keyboard.nextInt();
                }
                catch(NumberFormatException obj)
                {
                    System.out.println("Enter a valid number");
                    continue;
                }
                catch(Exception o)
                {
                    System.out.println("Error");
                    continue;
                }
                break;
            }
        }
        else 
        {
            while(true)
            {
                String x = keyboard.next();
                if(x.equals("="))
                {
                    return 0.1;
                }
            }
        }
        return res;
    }
    public static double mulInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        int res;
        if(keyboard.hasNextInt())
        {
            while(true)
            {
                try
                {
                    res=keyboard.nextInt();
                }
                catch(NumberFormatException obj)
                {
                    System.out.println("Enter a valid number");
                    continue;
                }
                catch(Exception o)
                {
                    System.out.println("Error");
                    continue;
                }
                break;
            }
        }
        else 
        {
            while(true)
            {
                String x = keyboard.next();
                if(x.equals("="))
                {
                    return 0.1;
                }
            }
        }
        return res;
    }
    public static double divInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        int res;
        if(keyboard.hasNextInt())
        {
            while(true)
            {
                try
                {
                    res=keyboard.nextInt();
                }
                catch(NumberFormatException obj)
                {
                    System.out.println("Enter a valid number");
                    continue;
                }
                catch(Exception o)
                {
                    System.out.println("Error");
                    continue;
                }
                break;
            }
        }
        else 
        {
            while(true)
            {
                String x = keyboard.next();
                if(x.equals("="))
                {
                    return 0.1;
                }
            }
        }
        return res;
    }
    public static double modInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        int res;
        if(keyboard.hasNextInt())
        {
            while(true)
            {
                try
                {
                    res=keyboard.nextInt();
                }
                catch(NumberFormatException obj)
                {
                    System.out.println("Enter a valid number");
                    continue;
                }
                catch(Exception o)
                {
                    System.out.println("Error");
                    continue;
                }
                break;
            }
        }
        else 
        {
            while(true)
            {
                String x = keyboard.next();
                if(x.equals("="))
                {
                    return 0.1;
                }
            }
        }
        return res;
    }
    public static double squareRootInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            if(res<=0)
            {
                System.out.println("Please enter a positive value");
                continue;
            }
            break;
        }
        return res;
    } 
    public static double rootToXInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            if(res<=0)
            {
                System.out.println("Please enter a positive value");
                continue;
            }
            break;
        }
        return res;
    }
    public static double squareInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double cubeInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double raiseToXInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double absInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double logInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            if(res<=0)
            {
                System.out.println("Enter a valid number greater than 0");
                continue;
            }
            break;
        }
        return res;
    }
    public static double expInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double roundInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static int trigoInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        int res;
        while(true)
        {
            try
            {
                res=keyboard.nextInt();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double cosInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double sinInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double tanInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double cotInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double secInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double cosecInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static double acosInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            if(res>1 || res<-1)
            {
                System.out.println("Val out of domain");
                continue;
            }
            break;
        }
        return res;
    }
    public static double asinInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            if(res>1 || res<-1)
            {
                System.out.println("Val out of domain");
                continue;
            }
            break;
        }
        return res;
    }
    public static double atanInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        double res;
        while(true)
        {
            try
            {
                res=keyboard.nextDouble();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static int wishInput(InputStream in)
    {
        Scanner keyboard = new Scanner(in);
        int res;
        while(true)
        {
            try
            {
                res=keyboard.nextInt();
            }
            catch(NumberFormatException obj)
            {
                System.out.println("Enter a valid number");
                continue;
            }
            catch(Exception o)
            {
                System.out.println("Error");
                continue;
            }
            break;
        }
        return res;
    }
    public static void main(String[] args)throws IOException
    {
    
        Calculator calc = new Calculator();
        // String myInput = "";
        // ByteArrayInputStream in = new ByteArrayInputStream(myInput.getBytes());
        InputStream in = System.in;
        while(true)
        {
            System.out.println("ENTER ONE FOR BASIC CALCULATOR");
            System.out.println("ENTER TWO FOR SCIENTIFIC CALCULATOR");
            calc.choice = Calculator.calcInput(in);
            switch(calc.choice)
            {
                case 1:
                    System.out.println("ENTER 1 FOR ADDITION");
                    System.out.println("ENTER 2 FOR SUBTRACTION");
                    System.out.println("ENTER 3 FOR MULTIPLICATION");
                    System.out.println("ENTER 4 FOR DIVISION");
                    System.out.println("ENTER 5 FOR MODULUS");
                    int cho = Calculator.normCalcInput(in);
                    int res = 0;
                    switch(cho)
                    {
                        case 1:
                        while(true)
                        {
                            double num = Calculator.addInput(in);
                            if(num==0.1)break;
                            res = calc.add((int)num,res);
                        }
                        System.out.println("Result = "+res);
                        break;
                        case 2:
                        int flag = 0;
                        while(true)
                        {
                            double num = Calculator.subInput(in);
                            if(num==0.1)break;
                            if(flag==0)res = (int)num;
                            else res = calc.subtract((int)num,res);
                            flag=1;
                        }
                        System.out.println("Result = "+res);
                        break;
                        case 3:
                        res = 1;
                        while(true)
                        {
                            double num = Calculator.mulInput(in);
                            if(num==0.1)break;
                            res = calc.multiply((int)num,res);
                        }
                        System.out.println("Result = "+res);
                        break;
                        case 4:
                        flag = 0;
                        while(true)
                        {
                            double num = Calculator.divInput(in);
                            if(num==0.1)break;
                            if(flag==1 && num==0)
                            {
                                System.out.println("Cannot divide by 0");
                                continue;
                            }
                            if(flag==0)res = (int)num;
                            else res = calc.divide((int)num,res);
                            flag=1;
                        }
                        System.out.println("Result = "+res);
                        break;
                        case 5:
                        flag = 0;
                        while(true)
                        {
                            double num = Calculator.modInput(in);
                            if(num==0.1)break;
                            if(flag==0)res = (int)num;
                            else res = calc.modulus((int)num,res);
                            flag=1;
                        }
                        System.out.println("Result = "+res);
                        break;
                        default:System.out.println("Invalid choice");
                    }
                    break;
                case 2:
                    System.out.println("ENTER 1 TO FIND SQUARE ROOT");
                    System.out.println("ENTER 2 TO FIND RAISE TO POWER 'x'");
                    System.out.println("ENTER 3  TO FIND SQUARE");    
                    System.out.println("ENTER 4  TO FIND CUBE");  
                    System.out.println("ENTER 5  TO FIND TRIGNOMETRICAL VALUES");  
                    System.out.println("ENTER 6  TO FIND ROOT TO X");  
                    System.out.println("ENTER 7  TO ABSOLUTE VALUE"); 
                    System.out.println("ENTER 8  TO FIND ROUNDED OFF VALUE");  
                    System.out.println("ENTER 9  TO FIND LOG");  
                    System.out.println("ENTER 10  TO FIND EXPONENTIAL VALUE");  
                    int c9 = Calculator.scientCalcInput(in);
                    double result = 0;
                    switch(c9)
                    {
                        case 1:
                        double x = Calculator.squareRootInput(in);
                        result = calc.squareroot(x);
                        System.out.println("Result = "+result);
                        break;
                        case 2:
                        x = Calculator.raiseToXInput(in);
                        double y = Calculator.raiseToXInput(in);
                        result = calc.raise_to_x(x,y);
                        System.out.println("Result = "+result);
                        break;
                        case 3:
                        x = Calculator.squareInput(in);
                        result = calc.square(x);
                        System.out.println("Result = "+result);
                        break;
                        case 4:
                        x = Calculator.cubeInput(in);
                        result = calc.cube(x);
                        System.out.println("Result = "+result);
                        break;
                        case 5:
                        System.out.println("Enter Your choice");
                        System.out.println("Enter one for cosine");
                        System.out.println("Enter two for sine");
                        System.out.println("Enter three for tangent");
                        System.out.println("Enter four for cotangent");
                        System.out.println("Enter five for secant");
                        System.out.println("Enter six for cosecant");
                        System.out.println("Enter seven for inverse-cosine");
                        System.out.println("Enter eight for inverse-sine");
                        System.out.println("Enter nine for inverse-tangent");
                        int ch = Calculator.trigoInput(in);
                        switch(ch)
                        {
                            case 1:
                            double theta = Calculator.cosInput(in);
                            result = calc.cosine(theta);
                            System.out.println("Result = "+result);
                            break;
                            case 2:
                            theta = Calculator.sinInput(in);
                            result = calc.sine(theta);
                            System.out.println("Result = "+result);
                            break;
                            case 3:
                            theta = Calculator.tanInput(in);
                            result = calc.tangent(theta);
                            System.out.println("Result = "+result);
                            break;
                            case 4:
                            theta = Calculator.cotInput(in);
                            result = calc.cotangent(theta);
                            System.out.println("Result = "+result);
                            break;
                            case 5:
                            theta = Calculator.secInput(in);
                            result = calc.secant(theta);
                            System.out.println("Result = "+result);
                            break;
                            case 6:
                            theta = Calculator.cosecInput(in);
                            result = calc.cosecant(theta);
                            System.out.println("Result = "+result);
                            break;
                            case 7:
                            double val = Calculator.acosInput(in);
                            result = calc.acosine(val);
                            System.out.println("Result = "+result);
                            break;
                            case 8:
                            val = Calculator.asinInput(in);
                            result = calc.asine(val);
                            System.out.println("Result = "+result);
                            break;
                            case 9:
                            val = Calculator.atanInput(in);
                            result = calc.atangent(val);
                            System.out.println("Result = "+result);
                            break;
                            default:System.out.println("Invalid choice");
                        }
                        break;
                        case 6:
                        x = Calculator.rootToXInput(in);
                        y = Calculator.rootToXInput(in);
                        result = calc.root_to_x(x,y);
                        System.out.println("Result = "+result);
                        break;
                        case 7:
                        x = Calculator.absInput(in);
                        result = calc.absolute(x);
                        System.out.println("Result = "+result);
                        break;
                        case 8:
                        x = Calculator.roundInput(in);
                        result = calc.round(x);
                        System.out.println("Result = "+result);
                        break;
                        case 9:
                        x = Calculator.logInput(in);
                        result = calc.log(x);
                        System.out.println("Result = "+result);
                        break;
                        case 10:
                        x = Calculator.expInput(in);
                        result = calc.exponential(x);
                        System.out.println("Result = "+result);
                        break;
                        default:System.out.println("Invalid choice");
                    }
                    break;
                default:System.out.println("Invalid choice");
            }
            System.out.println("ENTER 1 TO CONTINUE AND ANY OTHER NUMBER TO DISCONTINUE");
            int wish = Calculator.wishInput(in);
            if(wish==1)
            {
                continue;
            }
            else 
            {
                System.out.println("THANK YOU");
                break;
            }
        }
    }
    public int add(int num, int res)
    {
        res+=num;
        return res;
    }
    public int subtract(int num, int res)
    {
        res-=num;
        return res;
    }  
    public int multiply(int num, int res)
    {
        res*=num;
        return res;
    }   
    public int divide(int num, int res)
    {
        res/=num;
        return res;
    } 
    public int modulus(int num, int res)
    {
        res%=num;
        return res;
    }  
    public double squareroot(double num)
    {
        double result=Math.sqrt(num);
        return result;
    }
    public double root_to_x(double x, double y)
    {
        double result=Math.pow(x,(1.0/y));
        return result;
    }
    public double square(double num)
    {
        double result=Math.pow(num,2);
        return result;
    }
    public double cube(double num)
    {
        double result=Math.pow(num,3);
        return result;
    }
    public double raise_to_x(double x, double y)
    {
        double result=Math.pow(x,y);
        return result;
    }
    public double absolute(double num)
    {
        double result=Math.abs(num);
        return result;
    }
    public double log(double num)
    {
        double result=Math.log(num);
        return result;
    }
    public double exponential(double num)
    {
        double result=Math.exp(num);
        return result;
    }
    public double round(double num)
    {
        double result=Math.rint(num);
        return result;
    }
    public double cosine(double num)
    {
        double result=Math.cos(num*(Math.PI/180));
        return result;
    }
    public double sine(double num)
    {
        double result=Math.sin(num*(Math.PI/180));
        return result;
    }
    public double tangent(double num)
    {
        double result=Math.tan(num*(Math.PI/180));
        return result;
    }
    public double cotangent(double num)
    {
        double result=1.0/(Math.tan(num*(Math.PI/180)));
        return result;
    }
    public double secant(double num)
    {
        double result=1.0/(Math.cos(num*(Math.PI/180)));
        return result;
    }
    public double cosecant(double num)
    {
        double result=1.0/(Math.sin(num*(Math.PI/180)));
        return result;
    }
    public double acosine(double num)
    {
        double result=Math.acos(num)*180/Math.PI;
        return result;
    }
    public double asine(double num)
    {
        double result=Math.asin(num)*(180/Math.PI);
        return result;
    }
    public double atangent(double num)
    {
        double result=180*Math.atan(num)/Math.PI;
        return result;
    }
}